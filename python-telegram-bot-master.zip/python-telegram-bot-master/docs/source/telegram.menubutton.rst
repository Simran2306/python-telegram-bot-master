MenuButton
==========

.. autoclass:: telegram.MenuButton
    :members:
    :show-inheritance: