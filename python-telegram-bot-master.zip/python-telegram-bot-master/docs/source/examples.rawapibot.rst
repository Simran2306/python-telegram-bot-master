`rawapibot.py`
==============

This example uses only the pure, "bare-metal" API wrapper.



.. literalinclude:: ../../examples/rawapibot.py
   :language: python
   :linenos:
    