filters Module
==============

.. :bysource: since e.g filters.CHAT is much above filters.Chat() in the docs when it shouldn't.
   The classes in `filters.py` are sorted alphabetically such that :bysource: still is readable

.. automodule:: telegram.ext.filters
    :inherited-members: BaseFilter, MessageFilter, UpdateFilter, object
    :members:
    :show-inheritance:
    :member-order: bysource