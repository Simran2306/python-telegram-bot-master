``inlinebot.py``
================

.. literalinclude:: ../../examples/inlinebot.py
   :language: python
   :linenos:
    