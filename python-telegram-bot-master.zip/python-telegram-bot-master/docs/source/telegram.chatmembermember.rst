ChatMemberMember
================

.. autoclass:: telegram.ChatMemberMember
    :members:
    :show-inheritance:
