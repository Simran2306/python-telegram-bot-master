SuccessfulPayment
=================

.. autoclass:: telegram.SuccessfulPayment
    :members:
    :show-inheritance:
