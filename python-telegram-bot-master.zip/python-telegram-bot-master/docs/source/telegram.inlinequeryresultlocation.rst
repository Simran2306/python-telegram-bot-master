InlineQueryResultLocation
=========================

.. autoclass:: telegram.InlineQueryResultLocation
    :members:
    :show-inheritance:
