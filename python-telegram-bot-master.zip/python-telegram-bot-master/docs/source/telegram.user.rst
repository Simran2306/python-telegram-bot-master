User
====

.. autoclass:: telegram.User
    :members:
    :show-inheritance:
