PassportElementErrorTranslationFiles
====================================

.. autoclass:: telegram.PassportElementErrorTranslationFiles
    :members:
    :show-inheritance:
