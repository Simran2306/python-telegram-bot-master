BasePersistence
===============

.. autoclass:: telegram.ext.BasePersistence
    :members:
    :show-inheritance:
