``contexttypesbot.py``
======================

.. literalinclude:: ../../examples/contexttypesbot.py
   :language: python
   :linenos:
    