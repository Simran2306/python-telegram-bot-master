Bot
===

.. autoclass:: telegram.Bot
    :members:
    :show-inheritance:
