PassportElementErrorFiles
=========================

.. autoclass:: telegram.PassportElementErrorFiles
    :members:
    :show-inheritance:
